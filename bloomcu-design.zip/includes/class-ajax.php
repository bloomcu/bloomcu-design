<?php
namespace Design;

/**
 * REST_API Handler
 */
class Ajax {

	public function __construct() {}

	/**
	 * Save post data
	 */
	public function save_postdata( $post_id, $schema, $type ) {}
}
