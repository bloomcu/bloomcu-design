<?php
/**
 * Topbar
 * Rendered on frontend below WP Admin bar and show link to design.
 */
?>

<div class="bloom-design-bar">
  <p>This page has <a href="<?php echo $design_article; ?>" target="_blank">insights</a></p>
</div>
