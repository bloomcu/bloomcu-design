# BloomCU Design

Design made easier. Made by BloomCU.

## Changelog
**1.2.2**
*Release Date – Sept 30, 2022*
* Add design duplication functionality
* Prevent designs from being edited/archived by other designers

**1.2.1**
*Release Date – Sept 12, 2022*
* Automatically collapse sidebar when loaded on mobile devices

**1.2.0**
*Release Date – Sept 12, 2022*
* Add sidebar toggle

**1.1.1**
*Release Date – Sept 8, 2022*
* Stable version in production

**0.0.1**
*Release Date – July 10, 2022*
* Initial release of Design Plugin
