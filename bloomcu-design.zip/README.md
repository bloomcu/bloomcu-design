# BloomCU Design

Design made easier. Made by BloomCU.

## Changelog

**1.1.1**
*Release Date – Sept 8, 2022*
* Stable version in production

**0.0.1**
*Release Date – July 10, 2022*
* Initial release of Design Plugin
